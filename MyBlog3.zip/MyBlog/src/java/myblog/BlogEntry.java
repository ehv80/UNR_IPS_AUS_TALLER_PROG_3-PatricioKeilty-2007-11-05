package myblog;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BlogEntry implements Comparable{
	  private String _title;
	  private String _body;
	  private Date _created = new Date();
	  private int _id = 0; 
	  
	  public String getTitle(){
	    return _title;
	  }
	  
	  public void setTitle( String title){
	    _title = title;
	  }
	  
	  public String getBody(){
	    return _body;
	  }
	  
	  public void setBody(String body){
	    _body = body;
	  }
	  
	  public BlogEntry(){
	    this("","");
	  }
	  
	  public BlogEntry(String title, String body){
	    _title = title;
	    _body = body;
	  }

	  private List _comments = new ArrayList();
	  
	  public List getComments(){
		  return _comments;
	  }
	  
	  public void addComment(Comment comment){
		  _comments.add(comment);
	  }
	  
	  public int getNumberOfComments(){
		  return _comments.size();
	  }
	  
	  public Date getCreationDate(){
		  return _created;
	  }

	public int compareTo(Object arg0) {
		return -1 * _created.compareTo(((BlogEntry)arg0).getCreationDate());
	}

	/**
	 * @return db table id
	 */
	public int getId() {
		return _id;
	}

	/**
	 * @param id - db table id
	 */
	public void setId(int id) {
		this._id = id;
	}
}


